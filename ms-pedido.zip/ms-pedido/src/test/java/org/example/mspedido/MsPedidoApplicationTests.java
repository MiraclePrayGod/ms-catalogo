package org.example.mspedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPedidoApplicationTests {

    @Test
    void contextLoads() {
    }

}
